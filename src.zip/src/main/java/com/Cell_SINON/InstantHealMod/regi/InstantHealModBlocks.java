package com.Cell_SINON.InstantHealMod.regi;

import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;


import java.util.function.Supplier;

public class InstantHealModBlocks {

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, InstantHealMod.MOD_id);

    public static final RegistryObject<Block> FERMENTATIONBLOCK = BLOCKS.register("fermentationblock", ()-> new Block(BlockBehaviour.Properties.of()
            .strength(3.5F)
            .sound(SoundType.STONE)
            .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> ELECTROLYSIS_BLOCK = BLOCKS.register("electrolysis_block", ()-> new Block(BlockBehaviour.Properties.of()
            .strength(3.5F)
            .sound(SoundType.STONE)
            .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> DISTILlER_BLOCK = BLOCKS.register("distiller_block", ()-> new Block(BlockBehaviour.Properties.of()
            .strength(3.5F)
            .sound(SoundType.STONE)
            .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> CHEMICAL_REACTOR_BLOCK = BLOCKS.register("chemical_reactor_block", ()-> new Block(BlockBehaviour.Properties.of()
            .strength(3.5F)
            .sound(SoundType.STONE)
            .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> PYROLYZER_BLOCK = BLOCKS.register("pyrolyzer_block", ()-> new Block(BlockBehaviour.Properties.of()
            .strength(3.5F)
            .sound(SoundType.STONE)
            .requiresCorrectToolForDrops()));







    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
 }
