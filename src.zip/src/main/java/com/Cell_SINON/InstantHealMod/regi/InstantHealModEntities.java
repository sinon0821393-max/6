package com.Cell_SINON.InstantHealMod.regi;

import com.Cell_SINON.InstantHealMod.block.ChemicalReactor.ChemicalReactorBlockEntity;
import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerBlockEntity;
import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisBlockEntity;
import com.Cell_SINON.InstantHealMod.block.Pyrolysis.PyrolyzerBlockEntity;
import com.Cell_SINON.InstantHealMod.block.fermentation.FermentationBlockEntity;
import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InstantHealModEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCKENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, InstantHealMod.MOD_id);

    public static final RegistryObject<BlockEntityType<FermentationBlockEntity>> FEMENTATION_BLOCK_ENTITY =
            BLOCKENTITIES.register("fermentation_block_entity",()->
                    BlockEntityType.Builder.of(FermentationBlockEntity::new,
                            InstantHealModBlocks.FERMENTATIONBLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<ElectrolysisBlockEntity>> ELECTROLYSIS_BLOCK_ENTITY =
            BLOCKENTITIES.register("electrolysis_block_entity", () ->
                    BlockEntityType.Builder.of(ElectrolysisBlockEntity::new,
                            InstantHealModBlocks.ELECTROLYSIS_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<DistillerBlockEntity>> DISTILLER_BLOCK_ENTITY =
            BLOCKENTITIES.register("distiller_block_entity", () ->
                    BlockEntityType.Builder.of(DistillerBlockEntity::new,
                            InstantHealModBlocks.DISTILlER_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<ChemicalReactorBlockEntity>> CHEMICAL_REACTOR_BLOCK_ENTITY =
            BLOCKENTITIES.register("chemical_reactor_entity", () ->
                    BlockEntityType.Builder.of(ChemicalReactorBlockEntity::new,
                            InstantHealModBlocks.CHEMICAL_REACTOR_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<PyrolyzerBlockEntity>> PYROLYZER_BLOCK_ENTITY =
            BLOCKENTITIES.register("pyrolyzer_block_entity", () ->
                    BlockEntityType.Builder.of(PyrolyzerBlockEntity::new,
                            InstantHealModBlocks.PYROLYZER_BLOCK.get()).build(null));



    public static void register(IEventBus eventBus) {
        BLOCKENTITIES.register(eventBus);
    }

}
