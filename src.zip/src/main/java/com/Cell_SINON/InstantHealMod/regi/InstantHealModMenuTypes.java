package com.Cell_SINON.InstantHealMod.regi;

import com.Cell_SINON.InstantHealMod.block.fermentation.FermentationMenu;
import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InstantHealModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, InstantHealMod.MOD_id);

    public static final RegistryObject<MenuType<FermentationMenu>> FERMENTATION_MENU =
            MENUS.register("fermentation_menu", ()-> IForgeMenuType.create(FermentationMenu::new));

    public static final RegistryObject<MenuType<FermentationMenu>> ELECTROLYSISMENU =
            MENUS.register("electrolysismenu", ()-> IForgeMenuType.create(FermentationMenu::new));


    public static final RegistryObject<MenuType<FermentationMenu>> DISTILLER_MENU =
            MENUS.register("distiller_menu", ()-> IForgeMenuType.create(FermentationMenu::new));

    public static final RegistryObject<MenuType<FermentationMenu>> CHEMICAL_REACTOR_MENU =
            MENUS.register("chemical_reactor_menu", ()-> IForgeMenuType.create(FermentationMenu::new));

    public static final RegistryObject<MenuType<FermentationMenu>> PYROLYSIS_MENU =
            MENUS.register("pyrolysis_menu", ()-> IForgeMenuType.create(FermentationMenu::new));



    public static void register(IEventBus eventBus){
        MENUS.register(eventBus);
    }
}
