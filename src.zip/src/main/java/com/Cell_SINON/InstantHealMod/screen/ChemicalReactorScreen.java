package com.Cell_SINON.InstantHealMod.screen;

import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerMenu;
import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class ChemicalReactorScreen extends AbstractContainerScreen<DistillerMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(InstantHealMod.MOD_id, "textures/gui/chemical_block_gui.png");

    public ChemicalReactorScreen(DistillerMenu pMenu, Inventory pPlayerInventory, Component pTitle) {
        super(pMenu, pPlayerInventory, pTitle);
    }

    @Override
    protected void init() {
        super.init();
        // GUIのタイトルテキストの位置などを設定する場合はここに書く
        // 例: this.titleLabelY = 10;
    }

    /**
     * 背景を描画するメソッド
     */
    @Override
    protected void renderBg(GuiGraphics pGuiGraphics, float pPartialTick, int pMouseX, int pMouseY) {
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;

        // 1. GUIの背景全体を描画する
        pGuiGraphics.blit(TEXTURE, x, y, 0, 0, imageWidth, imageHeight);



        // 3. 進捗矢印を描画する
        if (menu.isCrafting()) {
            // 矢印の絵はテクスチャの (u=176, v=0) の位置にあると仮定
            // 矢印のサイズは 24x17 ピクセル
            pGuiGraphics.blit(TEXTURE, x + 76, y + 35, 176, 0, menu.getScaledProgress(), 17);
        }
    }





    /**
     * 画面全体を描画するメインメソッド
     */
    @Override
    public void render(GuiGraphics pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
        renderBackground(pGuiGraphics);
        super.render(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
        renderTooltip(pGuiGraphics, pMouseX, pMouseY);
    }
}
