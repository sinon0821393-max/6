package com.Cell_SINON.InstantHealMod.screen;

import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisMenu;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class ElectrolysisScreen extends AbstractContainerScreen<ElectrolysisMenu> {    private static final ResourceLocation TEXTURE =
        new ResourceLocation(InstantHealMod.MOD_id, "textures/gui/electrolysis_block_gui.png");

    public ElectrolysisScreen(ElectrolysisMenu pMenu, Inventory pPlayerInventory, Component pTitle) {
        super(pMenu, pPlayerInventory, pTitle);
    }

    @Override
    protected void init() {
        super.init();
        // GUIのタイトルテキストの位置などを設定する場合はここに書く
        // this.titleLabelY = ...;
    }

    /**
     * 背景を描画するメソッド
     * @param pGuiGraphics 描画用オブジェクト
     * @param pPartialTick ティック間の補間フレーム
     * @param pMouseX マウスのX座標
     * @param pMouseY マウスのY座標
     */
    @Override
    protected void renderBg(GuiGraphics pGuiGraphics, float pPartialTick, int pMouseX, int pMouseY) {
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;

        // 1. まず、GUIの背景全体を描画する
        // blit(テクスチャ, 描画X, 描画Y, テクスチャU, テクスチャV, 横幅, 縦幅)
        pGuiGraphics.blit(TEXTURE, x, y, 0, 0, imageWidth, imageHeight);

        // 2. 次に、進捗に応じて矢印を描画する
        renderProgressArrow(pGuiGraphics, x, y);

        if (menu.isCrafting()) {
            // 泡の絵はテクスチャの (u=176, v=0) の位置にあると仮定
            // 泡のテクスチャの高さを 16 ピクセルと仮定
            int progress = menu.getScaledProgress(); // getScaledProgressは高さを返すようにする

            // 左の泡
            // 描画Y座標を動かすことで、泡が下から上へ上がっていくように見せる
            pGuiGraphics.blit(TEXTURE, x + 45, y + 35 - progress, 176, 16 - progress, 16, progress);

            // 右の泡
            pGuiGraphics.blit(TEXTURE, x + 115, y + 35 - progress, 192, 16 - progress, 16, progress);
        }
    }

    /**
     * 進捗矢印を描画するためのヘルパーメソッド
     */
    private void renderProgressArrow(GuiGraphics pGuiGraphics, int x, int y) {
        // menu.isCrafting() は後でElectrolysisMenuに追加するメソッド
        if (menu.isCrafting()) {

            // --- あなたの図の矢印を描画 ---

            // 左上に向かう矢印
            // 矢印テクスチャのサイズを 12x15 ピクセルと仮定
            // テクスチャのUV座標 (176, 0) に上向き矢印を描いておく
            pGuiGraphics.blit(TEXTURE, x + 62, y + 35 - menu.getScaledProgress(), 176, 15 - menu.getScaledProgress(), 12, menu.getScaledProgress());

            // 右上に向かう矢印も描画する場合は、座標を変えてもう一度blitを呼ぶ
            pGuiGraphics.blit(TEXTURE, x + 102, y + 35 - menu.getScaledProgress(), 176, 15 - menu.getScaledProgress(), 12, menu.getScaledProgress());
        }
    }

    /**
     * 画面全体を描画するメインメソッド
     */
    @Override
    public void render(GuiGraphics pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
        // 背景を暗くする処理
        renderBackground(pGuiGraphics);
        // 背景とスロットを描画する
        super.render(pGuiGraphics, pMouseX, pMouseY, pPartialTick);
        // ツールチップ（アイテム名など）を描画する
        renderTooltip(pGuiGraphics, pMouseX, pMouseY);
    }

}
