package com.Cell_SINON.InstantHealMod.block.Electrolysis;

import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.SlotItemHandler;

public class ElectrolysisMenu extends AbstractContainerMenu {
    // --- 変数宣言 ---
    public final ElectrolysisBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    // --- コンストラクタ 1 (クライアントサイド用) ---
    // GUIが開かれる際に呼び出される
    public ElectrolysisMenu(int pContainerId, Inventory inv, FriendlyByteBuf extraData) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()), new SimpleContainerData(4));
    }

    // --- コンストラクタ 2 (サーバーサイド用 兼 共通処理用) ---
    // BlockEntityから、または上記のクライアント用コンストラクタから呼び出される
    public ElectrolysisMenu(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(InstantHealModMenuTypes.ELECTROLYSISMENU.get(), pContainerId);

        // BlockEntityの型チェックと、スロット数のチェック
        checkContainerSize(inv, 5);
        if (entity instanceof ElectrolysisBlockEntity be) {
            this.blockEntity = be;
        } else {
            // もし型が違っていたら、エラーを防ぐためにダミーの値を設定する（通常は起こらない）
            throw new IllegalStateException("Incorrect BlockEntity type provided!");
        }

        // 変数の初期化
        this.level = inv.player.level();
        this.data = data;

        // スロットの追加
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 0, 44, 53));
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 1, 116, 53));
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 2, 80, 53));
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 3, 44, 17));
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 4, 116, 17));

        addPlayerInventory(inv);
        addDataSlots(data);
    }

    // isCrafting と getScaledProgress メソッド
    public boolean isCrafting() { return this.data.get(0) > 0; }
    public int getScaledProgress() {
        int progress = this.data.get(0);
        int maxProgress = this.data.get(1);
        int bubbleHeight = 16; // 泡テクスチャの高さ
        return maxProgress != 0 && progress != 0 ? progress * bubbleHeight / maxProgress : 0;
    }

    // stillValid メソッド
    @Override
    public boolean stillValid(Player pPlayer) {
        return stillValid(ContainerLevelAccess.create(this.level, this.blockEntity.getBlockPos()),
                pPlayer, InstantHealModBlocks.ELECTROLYSIS_BLOCK.get());
    }

    // quickMoveStack メソッド
    @Override
    public ItemStack quickMoveStack(Player pPlayer, int pIndex) {
        Slot sourceSlot = this.slots.get(pIndex);
        if (sourceSlot == null || !sourceSlot.hasItem()) {
            return ItemStack.EMPTY; // 空のスロットなら何もしない
        }

        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack copyOfSourceStack = sourceStack.copy();

        // スロットのインデックス範囲
        final int PLAYER_INVENTORY_FIRST_SLOT_INDEX = 0;
        final int PLAYER_INVENTORY_SLOT_COUNT = 36;
        final int BLOCK_ENTITY_FIRST_SLOT_INDEX = PLAYER_INVENTORY_FIRST_SLOT_INDEX + PLAYER_INVENTORY_SLOT_COUNT; // 36
        final int BLOCK_ENTITY_SLOT_COUNT = 5;

        if (pIndex >= PLAYER_INVENTORY_FIRST_SLOT_INDEX && pIndex < BLOCK_ENTITY_FIRST_SLOT_INDEX) {
            // ケース1: プレイヤーインベントリからブロックのスロットへ移動
            if (!this.moveItemStackTo(sourceStack, BLOCK_ENTITY_FIRST_SLOT_INDEX, BLOCK_ENTITY_FIRST_SLOT_INDEX + BLOCK_ENTITY_SLOT_COUNT, false)) {
                return ItemStack.EMPTY;
            }
        } else if (pIndex >= BLOCK_ENTITY_FIRST_SLOT_INDEX && pIndex < BLOCK_ENTITY_FIRST_SLOT_INDEX + BLOCK_ENTITY_SLOT_COUNT) {
            // ケース2: ブロックのスロットからプレイヤーインベントリへ移動
            if (!this.moveItemStackTo(sourceStack, PLAYER_INVENTORY_FIRST_SLOT_INDEX, BLOCK_ENTITY_FIRST_SLOT_INDEX, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            // 予期せぬインデックス
            System.out.println("Invalid slot index: " + pIndex);
            return ItemStack.EMPTY;
        }

        if (sourceStack.isEmpty()) {
            sourceSlot.set(ItemStack.EMPTY);
        } else {
            sourceSlot.setChanged();
        }
        sourceSlot.onTake(pPlayer, sourceStack);
        return copyOfSourceStack;
    }

    // addPlayerInventory メソッド
    private void addPlayerInventory(Inventory playerInventory) {
        // プレイヤーのメインインベントリ (3x9スロット)
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }

        // プレイヤーのホットバー (1x9スロット)
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));

        }
    }
    private void addBlockEntitySlots() {
        // 左下触媒 (スロット0)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 0, 44, 53));
        // 右下触媒 (スロット1)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 1, 116, 53));
        // 中央水入力 (スロット2)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 2, 80, 53));
        // 左上瓶/出力 (スロット3)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 3, 44, 17));
        // 右上瓶/出力 (スロット4)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 4, 116, 17));
    }








}


