package com.Cell_SINON.InstantHealMod.block.Electrolysis;

import com.Cell_SINON.InstantHealMod.Recipe.ElectrolysisReactionRecipe;
import com.Cell_SINON.InstantHealMod.Recipe.ModRecipeTypes;
import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisMenu;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import com.Cell_SINON.InstantHealMod.screen.ElectrolysisScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class ElectrolysisBlockEntity extends BlockEntity implements MenuProvider {

    // --- 1. 変数(フィールド)定義 ---
    private final ItemStackHandler itemHandler = new ItemStackHandler(5);
    private static final int INGOT_SLOT_1 = 0, INGOT_SLOT_2 = 1, WATER_SLOT = 2, BOTTLE_SLOT_1 = 3, BOTTLE_SLOT_2 = 4;

    private int progress = 0;
    private int maxProgress = 200;
    private int ingotDurability1 = 0;
    private int ingotDurability2 = 0;
    public static final int MAX_DURABILITY = 3;
    protected final ContainerData data;

    public ElectrolysisBlockEntity(BlockPos pPos, BlockState pState) {
        super(InstantHealModEntities.ELECTROLYSIS_BLOCK_ENTITY.get(), pPos, pState);

        // --- ContainerDataの完全な実装 ---
        this.data = new ContainerData() {
            @Override
            public int get(int pIndex) {
                return switch (pIndex) {
                    case 0 -> ElectrolysisBlockEntity.this.progress;
                    case 1 -> ElectrolysisBlockEntity.this.maxProgress;
                    case 2 -> ElectrolysisBlockEntity.this.ingotDurability1;
                    case 3 -> ElectrolysisBlockEntity.this.ingotDurability2;
                    default -> 0;
                };
            }

            @Override
            public void set(int pIndex, int pValue) {
                switch (pIndex) {
                    case 0 -> ElectrolysisBlockEntity.this.progress = pValue;
                    case 1 -> ElectrolysisBlockEntity.this.maxProgress = pValue;
                    case 2 -> ElectrolysisBlockEntity.this.ingotDurability1 = pValue;
                    case 3 -> ElectrolysisBlockEntity.this.ingotDurability2 = pValue;
                }
            }

            @Override
            public int getCount() {
                return 4; // 同期するデータは4つ
            }
        };
    }

    // --- ここからが必須メソッド ---

    /**
     * GUIのタイトルを返すメソッド
     */
    @Override
    public Component getDisplayName() {
        return Component.translatable("block.instanthealmod.electrolysis_block");
    }

    /**
     * GUIのMenu(コンテナ)を生成するメソッド
     */
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return new ElectrolysisMenu(pContainerId, pPlayerInventory, this, this.data);
    }

    public ItemStackHandler getItemHandler() {
        return this.itemHandler;
    }

    // --- データの保存と読み込み ---
    @Override
    protected void saveAdditional(CompoundTag pTag) {
        pTag.put("inventory", this.itemHandler.serializeNBT());
        pTag.putInt("electrolysis.progress", this.progress);
        pTag.putInt("electrolysis.durability1", this.ingotDurability1);
        pTag.putInt("electrolysis.durability2", this.ingotDurability2);
        super.saveAdditional(pTag);
    }

    @Override
    public void load(CompoundTag pTag) {
        super.load(pTag);
        this.itemHandler.deserializeNBT(pTag.getCompound("inventory"));
        this.progress = pTag.getInt("electrolysis.progress");
        this.ingotDurability1 = pTag.getInt("electrolysis.durability1");
        this.ingotDurability2 = pTag.getInt("electrolysis.durability2");
    }

    // --- Tick処理とレシピのロジック ---
    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, ElectrolysisBlockEntity pBlockEntity) {
        if (pLevel.isClientSide()) return;
        pBlockEntity.lockIngotsIfNecessary();

        // レシピ検索の材料スロットを修正
        Optional<ElectrolysisReactionRecipe> recipe = pLevel.getRecipeManager()
                .getRecipeFor(ModRecipeTypes.ELECTROLYSIS_TYPE.get(), new SimpleContainer(
                        pBlockEntity.itemHandler.getStackInSlot(WATER_SLOT),
                        pBlockEntity.itemHandler.getStackInSlot(BOTTLE_SLOT_1)), pLevel);

        boolean hasCatalyst = pBlockEntity.ingotDurability1 > 0 && pBlockEntity.ingotDurability2 > 0;

        if (hasCatalyst && recipe.isPresent() && canInsertItemsIntoOutputSlots(pBlockEntity, recipe.get())) {
            pBlockEntity.progress++;
            setChanged(pLevel, pPos, pState);
            if (pBlockEntity.progress >= pBlockEntity.maxProgress) {
                craftItem(pBlockEntity, recipe.get());
                pBlockEntity.resetProgress();
            }
        } else {
            pBlockEntity.resetProgress();
            setChanged(pLevel, pPos, pState);
        }
    }

    private void resetProgress() { this.progress = 0; }

    private void lockIngotsIfNecessary() {
        // ここで指定するアイテムは、将来的にタグ(#forge:ingots/ironなど)を使うと、より拡張性が高くなります
        if (this.itemHandler.getStackInSlot(INGOT_SLOT_1).is(Items.IRON_INGOT) && this.ingotDurability1 == 0) {
            this.ingotDurability1 = MAX_DURABILITY;
        }
        if (this.itemHandler.getStackInSlot(INGOT_SLOT_2).is(Items.COPPER_INGOT) && this.ingotDurability2 == 0) {
            this.ingotDurability2 = MAX_DURABILITY;
        }
    }

    private static void craftItem(ElectrolysisBlockEntity pBlockEntity, ElectrolysisReactionRecipe pRecipe) {
        pBlockEntity.itemHandler.extractItem(BOTTLE_SLOT_1, 1, false);
        pBlockEntity.itemHandler.setStackInSlot(WATER_SLOT, new ItemStack(Items.BUCKET)); // 水バケツを空のバケツに

        pBlockEntity.ingotDurability1--;
        pBlockEntity.ingotDurability2--;

        if (pBlockEntity.ingotDurability1 <= 0) {
            pBlockEntity.itemHandler.setStackInSlot(INGOT_SLOT_1, ItemStack.EMPTY);
        }
        if (pBlockEntity.ingotDurability2 <= 0) {
            pBlockEntity.itemHandler.setStackInSlot(INGOT_SLOT_2, ItemStack.EMPTY);
        }

        // 出力スロットは瓶スロットを上書きする
        pBlockEntity.itemHandler.setStackInSlot(BOTTLE_SLOT_1, new ItemStack(pRecipe.getOutput1().getItem()));
        pBlockEntity.itemHandler.setStackInSlot(BOTTLE_SLOT_2, new ItemStack(pRecipe.getOutput2().getItem()));
    }

    private static boolean canInsertItemsIntoOutputSlots(ElectrolysisBlockEntity pBlockEntity, ElectrolysisReactionRecipe pRecipe) {
        // 出力先となる瓶スロット1と2が空であること
        // (厳密には、レシピの出力と一致していてスタック可能ならOK、というロジックにもできる)
        return pBlockEntity.itemHandler.getStackInSlot(BOTTLE_SLOT_1).is(Items.GLASS_BOTTLE) &&
                pBlockEntity.itemHandler.getStackInSlot(BOTTLE_SLOT_2).is(Items.GLASS_BOTTLE);
    }
}