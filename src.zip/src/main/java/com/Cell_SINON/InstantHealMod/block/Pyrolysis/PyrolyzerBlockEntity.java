package com.Cell_SINON.InstantHealMod.block.Pyrolysis;

import com.Cell_SINON.InstantHealMod.Recipe.DistillationRecipe;
import com.Cell_SINON.InstantHealMod.Recipe.ModRecipeTypes;
import com.Cell_SINON.InstantHealMod.Recipe.PyrolysisRecipe;
import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerBlockEntity;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerMenu; // 後で作る
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;


public class PyrolyzerBlockEntity extends BlockEntity implements MenuProvider{

    private final ItemStackHandler itemHandler = new ItemStackHandler(4);
    private static final int FUEL_SLOT = 0, INPUT_SLOT = 1, OUTPUT_SLOT_1 = 2, OUTPUT_SLOT_2 = 3;

    private int progress = 0, maxProgress = 200;
    private int fuelTime = 0, maxFuelTime = 0;
    protected final ContainerData data;

    public PyrolyzerBlockEntity(BlockPos pPos, BlockState pState) {
        super(InstantHealModEntities.PYROLYZER_BLOCK_ENTITY.get(), pPos, pState);
        this.data = new ContainerData() {
            public int get(int index) {
                return switch (index) {
                    case 0 -> PyrolyzerBlockEntity.this.progress;
                    case 1 -> PyrolyzerBlockEntity.this.maxProgress;
                    case 2 -> PyrolyzerBlockEntity.this.fuelTime;
                    case 3 -> PyrolyzerBlockEntity.this.maxFuelTime;
                    default -> 0;
                };
            }
            public void set(int index, int value) {
                switch (index) {
                    case 0 -> PyrolyzerBlockEntity.this.progress = value;
                    case 1 -> PyrolyzerBlockEntity.this.maxProgress = value;
                    case 2 -> PyrolyzerBlockEntity.this.fuelTime = value;
                    case 3 -> PyrolyzerBlockEntity.this.maxFuelTime = value;
                }
            }
            public int getCount() { return 4; }
        };
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.instanthealmod.pyrolyzer_block");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return new PyrolysisMenu(pContainerId, pPlayerInventory, this, this.data);
    }

    // ... (getItemHandler, saveAdditional, load メソッドはDistillerとほぼ同じ)

    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, PyrolyzerBlockEntity pBlockEntity) {
        if (pLevel.isClientSide()) return;

        boolean isBurning = pBlockEntity.fuelTime > 0;
        if (isBurning) pBlockEntity.fuelTime--;

        Optional<PyrolysisRecipe> recipe = pLevel.getRecipeManager()
                .getRecipeFor(ModRecipeTypes.PYROLYSIS_TYPE.get(), new SimpleContainer(pBlockEntity.itemHandler.getStackInSlot(INPUT_SLOT)), pLevel);

        if (recipe.isPresent() && canInsertItemsIntoOutputSlots(pBlockEntity, recipe.get())) {
            if (!isBurning && !pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT).isEmpty()) {
                pBlockEntity.fuelTime = ForgeHooks.getBurnTime(pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT), RecipeType.SMELTING);
                pBlockEntity.maxFuelTime = pBlockEntity.fuelTime;
                pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT).shrink(1);
            }
            if (pBlockEntity.fuelTime > 0) {
                pBlockEntity.progress++;
                setChanged(pLevel, pPos, pState);
                if (pBlockEntity.progress >= pBlockEntity.maxProgress) {
                    craftItem(pBlockEntity, recipe.get());
                    pBlockEntity.resetProgress();
                }
            }
        } else {
            pBlockEntity.resetProgress();
            setChanged(pLevel, pPos, pState);
        }
    }

    private void resetProgress() { this.progress = 0; }

    private static void craftItem(PyrolyzerBlockEntity pBlockEntity, PyrolysisRecipe pRecipe) {
        pBlockEntity.itemHandler.extractItem(INPUT_SLOT, 1, false);

        pBlockEntity.itemHandler.setStackInSlot(OUTPUT_SLOT_1, new ItemStack(pRecipe.getOutput1().getItem(),
                pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).getCount() + pRecipe.getOutput1().getCount()));
        pBlockEntity.itemHandler.setStackInSlot(OUTPUT_SLOT_2, new ItemStack(pRecipe.getOutput2().getItem(),
                pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).getCount() + pRecipe.getOutput2().getCount()));
    }

    private static boolean canInsertItemsIntoOutputSlots(PyrolyzerBlockEntity pBlockEntity, PyrolysisRecipe pRecipe) {
        ItemStack output1 = pRecipe.getOutput1();
        ItemStack output2 = pRecipe.getOutput2();

        boolean canInsertOutput1 = pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).isEmpty() || pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).is(output1.getItem());
        boolean canInsertOutput2 = pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).isEmpty() || pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).is(output2.getItem());

        return canInsertOutput1 && canInsertOutput2;
    }

    public ItemStackHandler getItemHandler() {
        return this.itemHandler;
    }
}
