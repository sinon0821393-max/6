package com.Cell_SINON.InstantHealMod.block.fermentation;

import com.Cell_SINON.InstantHealMod.Recipe.FermentationRecipe;
import com.Cell_SINON.InstantHealMod.Recipe.ModRecipeTypes;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nullable;
import java.util.Optional;

public class FermentationBlockEntity extends BlockEntity implements MenuProvider {

    private final ItemStackHandler itemHandler = new ItemStackHandler(4);
    private static final int INPUT_SLOT_1 = 0, INPUT_SLOT_2 = 1, OUTPUT_SLOT_1 = 2, OUTPUT_SLOT_2 = 3;

    private int progress = 0;
    private int maxProgress = 100;
    protected final ContainerData data;

    public FermentationBlockEntity(BlockPos pPos, BlockState pState) {
        super(InstantHealModEntities.FEMENTATION_BLOCK_ENTITY.get(), pPos, pState);
        this.data = new ContainerData() {
            public int get(int index) { return index == 0 ? FermentationBlockEntity.this.progress : FermentationBlockEntity.this.maxProgress; }
            public void set(int index, int value) { if(index == 0) FermentationBlockEntity.this.progress = value; else FermentationBlockEntity.this.maxProgress = value; }
            public int getCount() { return 2; }
        };
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.instanthealmod.fermentation_block");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return new FermentationMenu(pContainerId, pPlayerInventory, this, this.data);
    }

    public ItemStackHandler getItemHandler() {
        return this.itemHandler;
    }

    @Override
    protected void saveAdditional(CompoundTag pTag) {
        pTag.put("inventory", this.itemHandler.serializeNBT());
        pTag.putInt("fermentation.progress", this.progress);
        super.saveAdditional(pTag);
    }

    @Override
    public void load(CompoundTag pTag) {
        super.load(pTag);
        this.itemHandler.deserializeNBT(pTag.getCompound("inventory"));
        this.progress = pTag.getInt("fermentation.progress");
    }

    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, FermentationBlockEntity pBlockEntity) {
        if (pLevel.isClientSide()) return;

        Optional<FermentationRecipe> recipe = pLevel.getRecipeManager()
                .getRecipeFor(ModRecipeTypes.FERMENTATION_TYPE.get(), new SimpleContainer(
                        pBlockEntity.itemHandler.getStackInSlot(INPUT_SLOT_1),
                        pBlockEntity.itemHandler.getStackInSlot(INPUT_SLOT_2)), pLevel);

        if (recipe.isPresent() && canInsertItemsIntoOutputSlots(pBlockEntity, recipe.get())) {
            pBlockEntity.progress++;
            setChanged(pLevel, pPos, pState);
            if (pBlockEntity.progress >= pBlockEntity.maxProgress) {
                craftItem(pBlockEntity, recipe.get());
                pBlockEntity.resetProgress();
            }
        } else {
            pBlockEntity.resetProgress();
            setChanged(pLevel, pPos, pState);
        }
    }

    private void resetProgress() { this.progress = 0; }

    private static void craftItem(FermentationBlockEntity pBlockEntity, FermentationRecipe pRecipe) {
        pBlockEntity.itemHandler.extractItem(INPUT_SLOT_1, 1, false);
        pBlockEntity.itemHandler.extractItem(INPUT_SLOT_2, 1, false);

        pBlockEntity.itemHandler.setStackInSlot(OUTPUT_SLOT_1, new ItemStack(pRecipe.getOutput1().getItem(),
                pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).getCount() + pRecipe.getOutput1().getCount()));
        pBlockEntity.itemHandler.setStackInSlot(OUTPUT_SLOT_2, new ItemStack(pRecipe.getOutput2().getItem(),
                pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).getCount() + pRecipe.getOutput2().getCount()));
    }

    private static boolean canInsertItemsIntoOutputSlots(FermentationBlockEntity pBlockEntity, FermentationRecipe pRecipe) {
        ItemStack output1 = pRecipe.getOutput1();
        ItemStack output2 = pRecipe.getOutput2();

        boolean canInsertOutput1 = pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).isEmpty() || pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_1).is(output1.getItem());
        boolean canInsertOutput2 = pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).isEmpty() || pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT_2).is(output2.getItem());

        return canInsertOutput1 && canInsertOutput2;
    }
}
