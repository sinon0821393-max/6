package com.Cell_SINON.InstantHealMod.block.ChemicalReactor;

import com.Cell_SINON.InstantHealMod.Recipe.ChemicalReactionRecipe;
import com.Cell_SINON.InstantHealMod.Recipe.ModRecipeTypes;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.block.ChemicalReactor.ChemicalReactorMenu; // 後で作成
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;
import java.util.Optional;

public class ChemicalReactorBlockEntity extends BlockEntity implements MenuProvider {

    // --- インベントリとスロット定義 ---
    private final ItemStackHandler itemHandler = new ItemStackHandler(4); // 左入力, 中央入力, 右上出力, 右下出力
    private static final int LEFT_INPUT_SLOT = 0;
    private static final int MIDDLE_INPUT_SLOT = 1;
    private static final int TOP_OUTPUT_SLOT = 2;
    private static final int BOTTOM_OUTPUT_SLOT = 3;

    // --- データ変数 ---
    private int progress = 0;
    private int maxProgress = 200; // 10秒で完成
    protected final ContainerData data;

    // --- コンストラクタ ---
    public ChemicalReactorBlockEntity(BlockPos pPos, BlockState pState) {
        super(InstantHealModEntities.CHEMICAL_REACTOR_BLOCK_ENTITY.get(), pPos, pState); // 後で登録
        this.data = new ContainerData() {
            @Override
            public int get(int pIndex) {
                return pIndex == 0 ? ChemicalReactorBlockEntity.this.progress : ChemicalReactorBlockEntity.this.maxProgress;
            }
            @Override
            public void set(int pIndex, int pValue) {
                if (pIndex == 0) ChemicalReactorBlockEntity.this.progress = pValue;
                else ChemicalReactorBlockEntity.this.maxProgress = pValue;
            }
            @Override
            public int getCount() { return 2; }
        };
    }

    // --- GUI関連の必須メソッド ---
    @Override
    public Component getDisplayName() {
        return Component.translatable("block.instanthealmod.chemical_reactor"); // langファイルで定義
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return new ChemicalReactorMenu(pContainerId, pPlayerInventory, this, this.data); // 後で作成
    }

    public ItemStackHandler getItemHandler() {
        return this.itemHandler;
    }

    // --- データの保存と読み込み ---
    @Override
    protected void saveAdditional(CompoundTag pTag) {
        pTag.put("inventory", this.itemHandler.serializeNBT());
        pTag.putInt("reactor.progress", this.progress);
        super.saveAdditional(pTag);
    }
    @Override
    public void load(CompoundTag pTag) {
        super.load(pTag);
        this.itemHandler.deserializeNBT(pTag.getCompound("inventory"));
        this.progress = pTag.getInt("reactor.progress");
    }

    // --- Tick処理（機械の心臓部） ---
    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, ChemicalReactorBlockEntity pBlockEntity) {
        if (pLevel.isClientSide()) {
            return;
        }

        // 現在のインベントリに一致するレシピを探す
        Optional<ChemicalReactionRecipe> recipe = pLevel.getRecipeManager()
                .getRecipeFor(ModRecipeTypes.CHEMICAL_REACTION_TYPE.get(), pBlockEntity.getContainerForRecipe(), pLevel);

        // レシピが存在し、かつ出力スロットに空きがあれば処理を進める
        if (recipe.isPresent() && canInsertItemsIntoOutputSlots(pBlockEntity, recipe.get())) {
            pBlockEntity.progress++;
            setChanged(pLevel, pPos, pState);

            if (pBlockEntity.progress >= pBlockEntity.maxProgress) {
                craftItem(pBlockEntity, recipe.get());
                pBlockEntity.resetProgress();
            }
        } else {
            pBlockEntity.resetProgress();
            setChanged(pLevel, pPos, pState);
        }
    }

    private void resetProgress() {
        this.progress = 0;
    }

    // レシピ検索のために、材料スロットの中身だけをコンテナに詰める
    private SimpleContainer getContainerForRecipe() {
        SimpleContainer container = new SimpleContainer(2);
        container.setItem(0, this.itemHandler.getStackInSlot(LEFT_INPUT_SLOT));
        container.setItem(1, this.itemHandler.getStackInSlot(MIDDLE_INPUT_SLOT));
        return container;
    }

    // レシピに基づいてアイテムを生成する
    private static void craftItem(ChemicalReactorBlockEntity pBlockEntity, ChemicalReactionRecipe pRecipe) {
        // レシピから完成品を取得
        ItemStack output1 = pRecipe.getOutput1();
        ItemStack output2 = pRecipe.getOutput2();

        // 材料を1つずつ消費する
        pBlockEntity.itemHandler.extractItem(LEFT_INPUT_SLOT, 1, false);
        pBlockEntity.itemHandler.extractItem(MIDDLE_INPUT_SLOT, 1, false);

        // 出力スロットにアイテムをセットする
        pBlockEntity.itemHandler.setStackInSlot(TOP_OUTPUT_SLOT, new ItemStack(output1.getItem(),
                pBlockEntity.itemHandler.getStackInSlot(TOP_OUTPUT_SLOT).getCount() + output1.getCount()));
        pBlockEntity.itemHandler.setStackInSlot(BOTTOM_OUTPUT_SLOT, new ItemStack(output2.getItem(),
                pBlockEntity.itemHandler.getStackInSlot(BOTTOM_OUTPUT_SLOT).getCount() + output2.getCount()));
    }

    // 出力スロットに空きがあるか確認する
    private static boolean canInsertItemsIntoOutputSlots(ChemicalReactorBlockEntity pBlockEntity, ChemicalReactionRecipe pRecipe) {
        ItemStack output1 = pRecipe.getOutput1();
        ItemStack output2 = pRecipe.getOutput2();

        boolean canInsertOutput1 = pBlockEntity.itemHandler.getStackInSlot(TOP_OUTPUT_SLOT).isEmpty() ||
                (pBlockEntity.itemHandler.getStackInSlot(TOP_OUTPUT_SLOT).is(output1.getItem()) &&
                        pBlockEntity.itemHandler.getStackInSlot(TOP_OUTPUT_SLOT).getCount() + output1.getCount() <= output1.getMaxStackSize());

        boolean canInsertOutput2 = pBlockEntity.itemHandler.getStackInSlot(BOTTOM_OUTPUT_SLOT).isEmpty() ||
                (pBlockEntity.itemHandler.getStackInSlot(BOTTOM_OUTPUT_SLOT).is(output2.getItem()) &&
                        pBlockEntity.itemHandler.getStackInSlot(BOTTOM_OUTPUT_SLOT).getCount() + output2.getCount() <= output2.getMaxStackSize());

        return canInsertOutput1 && canInsertOutput2;
    }
}



