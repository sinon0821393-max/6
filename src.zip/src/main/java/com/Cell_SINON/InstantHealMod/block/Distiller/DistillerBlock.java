package com.Cell_SINON.InstantHealMod.block.Distiller;

import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisBlockEntity;
import com.Cell_SINON.InstantHealMod.block.Pyrolysis.PyrolyzerBlockEntity;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class DistillerBlock extends BaseEntityBlock {

    public DistillerBlock(Properties pProperties) {
        super(pProperties);
    }
    @Override
    public RenderShape getRenderShape(BlockState pState) {
        return RenderShape.MODEL;
    }
    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pPos, BlockState pState) {
        return new DistillerBlockEntity(pPos, pState);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level pLevel, BlockState pState, BlockEntityType<T> pBlockEntityType) {
        // サーバーサイドでのみtick処理（毎フレームの更新処理）を実行するように設定します。
        if (pLevel.isClientSide()) {
            return null; // クライアントサイドでは何もしない
        }

        // 正しいBlockEntityの型であることを確認し、tickメソッドを呼び出すように設定
        return createTickerHelper(pBlockEntityType, InstantHealModEntities.DISTILLER_BLOCK_ENTITY.get(), DistillerBlockEntity::tick);
    }


    @Override
    public InteractionResult use(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        // サーバーサイドでのみGUIを開く処理を行う
        if (!pLevel.isClientSide()) {

            // 1. まず、BlockEntityを取得する
            BlockEntity entity = pLevel.getBlockEntity(pPos);

            // 2. 取得したBlockEntityが、本当にDistillerBlockEntityかを確認する
            if (entity instanceof DistillerBlockEntity) {
                // 3. もし正しければ、GUIを開く
                NetworkHooks.openScreen((ServerPlayer) pPlayer, (DistillerBlockEntity) entity, pPos);
            }
            // 4. もし、何らかの理由でBlockEntityが見つからなかったり、型が違っていたりした場合
            else {
                throw new IllegalStateException("Our Container provider is missing for DistillerBlock!");
            }
        }

        // 常にこの値を返すことで、クライアントとサーバーのアクションの整合性を保つ
        return InteractionResult.sidedSuccess(pLevel.isClientSide());
    }






    }











