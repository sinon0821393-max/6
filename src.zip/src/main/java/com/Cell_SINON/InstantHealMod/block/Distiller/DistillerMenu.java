package com.Cell_SINON.InstantHealMod.block.Distiller;

import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.items.SlotItemHandler;

public class DistillerMenu extends AbstractContainerMenu {
    // --- 変数宣言 ---
    public final DistillerBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    // --- コンストラクタ 1 (クライアントサイド用) ---
    public DistillerMenu(int pContainerId, Inventory inv, FriendlyByteBuf extraData) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()), new SimpleContainerData(4));
    }

    // --- コンストラクタ 2 (サーバーサイド用 兼 共通処理用) ---
    public DistillerMenu(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(InstantHealModMenuTypes.DISTILLER_MENU.get(), pContainerId);

        // スロット数とBlockEntityの型をチェック
        checkContainerSize(inv, 3);
        if (entity instanceof DistillerBlockEntity be) {
            this.blockEntity = be;
        } else {
            throw new IllegalStateException("Incorrect BlockEntity type provided!");
        }

        this.level = inv.player.level();
        this.data = data;

        // スロットを追加
        addPlayerInventory(inv);
        addBlockEntitySlots();

        // データを同期
        addDataSlots(data);
    }

    // --- GUIと同期するための計算メソッド ---
    public boolean isBurning() {
        return this.data.get(2) > 0;
    }
    public boolean isCrafting() {
        return this.data.get(0) > 0;
    }
    public int getScaledFuelProgress() {
        int fuelTime = this.data.get(2);
        int maxFuelTime = this.data.get(3);
        int flameHeight = 14;
        if (maxFuelTime == 0) { maxFuelTime = 200; }
        return fuelTime * flameHeight / maxFuelTime;
    }
    public int getScaledProgress() {
        int progress = this.data.get(0);
        int maxProgress = this.data.get(1);
        int progressArrowWidth = 24;
        return maxProgress != 0 && progress != 0 ? progress * progressArrowWidth / maxProgress : 0;
    }

    // --- 必須のオーバーライドメソッド ---
    @Override
    public boolean stillValid(Player pPlayer) {
        return stillValid(ContainerLevelAccess.create(this.level, this.blockEntity.getBlockPos()),
                pPlayer, InstantHealModBlocks.DISTILlER_BLOCK.get());
    }

    @Override
    public ItemStack quickMoveStack(Player pPlayer, int pIndex) {
        Slot sourceSlot = this.slots.get(pIndex);
        if (sourceSlot == null || !sourceSlot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack copyOfSourceStack = sourceStack.copy();

        final int PLAYER_INV_FIRST = 0;
        final int PLAYER_INV_LAST = 36;
        final int BLOCK_ENTITY_FIRST = 36;
        final int FUEL_SLOT_INDEX = 36;
        final int INPUT_SLOT_INDEX = 37;
        final int OUTPUT_SLOT_INDEX = 38;

        if (pIndex < PLAYER_INV_FIRST) {
            // プレイヤーインベントリ -> ブロックへ
            // 燃料は燃料スロット(36)に、それ以外は入力スロット(37)に入れる
            if (ForgeHooks.getBurnTime(sourceStack, null) > 0) {
                if (!this.moveItemStackTo(sourceStack, FUEL_SLOT_INDEX, FUEL_SLOT_INDEX + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else {
                if (!this.moveItemStackTo(sourceStack, INPUT_SLOT_INDEX + 1, INPUT_SLOT_INDEX + 2, false)) {
                    return ItemStack.EMPTY;
                }
            }
        } else if (pIndex >= BLOCK_ENTITY_FIRST) {
            // ブロック -> プレイヤーインベントリへ
            if (!this.moveItemStackTo(sourceStack, PLAYER_INV_FIRST, PLAYER_INV_LAST, false)) {
                return ItemStack.EMPTY;
            }
        }

        if (sourceStack.isEmpty()) sourceSlot.set(ItemStack.EMPTY);

         else sourceSlot.setChanged();

        sourceSlot.onTake(pPlayer, sourceStack);

        return copyOfSourceStack;
    }

    // --- ヘルパーメソッド ---
    private void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }



    private void addBlockEntitySlots() {
        // 左 (燃料スロット)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 0, 56, 53));
        // 中央 (入力スロット)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 1, 80, 21));
        // 右 (出力スロット)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 2, 116, 21));
    }



}
