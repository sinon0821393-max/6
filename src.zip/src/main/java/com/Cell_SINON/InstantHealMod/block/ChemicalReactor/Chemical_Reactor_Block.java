package com.Cell_SINON.InstantHealMod.block.ChemicalReactor;

import com.Cell_SINON.InstantHealMod.block.ChemicalReactor.ChemicalReactorBlockEntity;
import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisBlockEntity;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

public class Chemical_Reactor_Block extends BaseEntityBlock{

    public Chemical_Reactor_Block(Properties pProperties) {
        super(pProperties);
    }

    /* ========== Block Entity Boilerplate (お決まりのコード) ========== */

    @Override
    public RenderShape getRenderShape(BlockState pState) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pPos, BlockState pState) {
        // ここで ChemicalReactorBlockEntity を生成する
        return new ChemicalReactorBlockEntity(pPos, pState);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level pLevel, BlockState pState, BlockEntityType<T> pBlockEntityType) {
        if (pLevel.isClientSide()) {
            return null;
        }

        // 正しいBlockEntityの型と、そのtickメソッドを指定する
        return createTickerHelper(pBlockEntityType, InstantHealModEntities.CHEMICAL_REACTOR_BLOCK_ENTITY.get(), ChemicalReactorBlockEntity::tick);
    }


    /* ========== GUI Opening Logic ========== */

    @Override
    public InteractionResult use(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        if (!pLevel.isClientSide()) {
            BlockEntity entity = pLevel.getBlockEntity(pPos);
            if (entity instanceof ChemicalReactorBlockEntity) {
                NetworkHooks.openScreen((ServerPlayer) pPlayer, (ChemicalReactorBlockEntity) entity, pPos);
            } else {
                throw new IllegalStateException("Our Container provider is missing for ChemicalReactorBlock!");
            }
        }

        return InteractionResult.sidedSuccess(pLevel.isClientSide());
    }
}
