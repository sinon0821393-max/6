package com.Cell_SINON.InstantHealMod.block.Pyrolysis;

import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerBlockEntity;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.items.SlotItemHandler;


public class PyrolysisMenu extends AbstractContainerMenu{

    public final PyrolyzerBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    // --- コンストラクタ 1 (クライアントサイド用) ---
    public PyrolysisMenu(int pContainerId, Inventory inv, FriendlyByteBuf extraData) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()), new SimpleContainerData(4));
    }

    // --- コンストラクタ 2 (サーバーサイド用 兼 共通処理用) ---
    public PyrolysisMenu(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(InstantHealModMenuTypes.PYROLYSIS_MENU .get(), pContainerId);

        // スロット数とBlockEntityの型をチェック
        checkContainerSize(inv, 3);
        if (entity instanceof PyrolyzerBlockEntity be) {
            this.blockEntity = be;
        } else {
            throw new IllegalStateException("Incorrect BlockEntity type provided!");
        }

        this.level = inv.player.level();
        this.data = data;

        // スロットを追加
        addPlayerInventory(inv);
        addBlockEntitySlots();

        // データを同期
        addDataSlots(data);
    }

    // --- GUIと同期するための計算メソッド ---
    public boolean isBurning() {
        return this.data.get(2) > 0;
    }
    public boolean isCrafting() {
        return this.data.get(0) > 0;
    }
    public int getScaledFuelProgress() {
        int fuelTime = this.data.get(2);
        int maxFuelTime = this.data.get(3);
        int flameHeight = 14;
        if (maxFuelTime == 0) { maxFuelTime = 200; }
        return fuelTime * flameHeight / maxFuelTime;
    }
    public int getScaledProgress() {
        int progress = this.data.get(0);
        int maxProgress = this.data.get(1);
        int progressArrowWidth = 24;
        return maxProgress != 0 && progress != 0 ? progress * progressArrowWidth / maxProgress : 0;
    }

    // --- 必須のオーバーライドメソッド ---
    @Override
    public boolean stillValid(Player pPlayer) {
        return stillValid(ContainerLevelAccess.create(this.level, this.blockEntity.getBlockPos()),
                pPlayer, InstantHealModBlocks.DISTILlER_BLOCK.get());
    }

    @Override
    public ItemStack quickMoveStack(Player pPlayer, int pIndex) {
        Slot sourceSlot = this.slots.get(pIndex);
        if (sourceSlot == null || !sourceSlot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack copyOfSourceStack = sourceStack.copy();

        final int PLAYER_INVENTORY_FIRST_SLOT_INDEX = 0;
        final int PLAYER_INVENTORY_SLOT_COUNT = 36;
        final int BLOCK_ENTITY_FIRST_SLOT_INDEX = 36;

        if (pIndex < PLAYER_INVENTORY_SLOT_COUNT) {
            // プレイヤーインベントリ -> ブロックへ
            // 燃料は燃料スロット(36)に、それ以外は入力スロット(37)に入れる
            if (ForgeHooks.getBurnTime(sourceStack, null) > 0) {
                if (!this.moveItemStackTo(sourceStack, BLOCK_ENTITY_FIRST_SLOT_INDEX, BLOCK_ENTITY_FIRST_SLOT_INDEX + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else {
                if (!this.moveItemStackTo(sourceStack, BLOCK_ENTITY_FIRST_SLOT_INDEX + 1, BLOCK_ENTITY_FIRST_SLOT_INDEX + 2, false)) {
                    return ItemStack.EMPTY;
                }
            }
        } else {
            // ブロック -> プレイヤーインベントリへ
            if (!this.moveItemStackTo(sourceStack, PLAYER_INVENTORY_FIRST_SLOT_INDEX, PLAYER_INVENTORY_SLOT_COUNT, false)) {
                return ItemStack.EMPTY;
            }
        }

        if (sourceStack.isEmpty()) {
            sourceSlot.set(ItemStack.EMPTY);
        } else {
            sourceSlot.setChanged();
        }
        sourceSlot.onTake(pPlayer, sourceStack);
        return copyOfSourceStack;
    }

    // --- ヘルパーメソッド ---
    private void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }
    private void addBlockEntitySlots() {
        // あなたの手書きの図に合わせたスロット配置
        // スロット番号と座標(x, y)を調整

        // 左 (燃料スロット) - スロット番号 0
        // 左 (燃料スロット)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 0, 24, 53));

        // 中央 (入力スロット)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 1, 62, 26));

        // 右上 (出力スロット1)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 2, 116, 17));

        // 右下 (出力スロット2)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 3, 116, 35));
    }








}
