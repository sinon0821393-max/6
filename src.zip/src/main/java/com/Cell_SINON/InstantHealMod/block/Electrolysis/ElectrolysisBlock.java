package com.Cell_SINON.InstantHealMod.block.Electrolysis;

import com.Cell_SINON.InstantHealMod.block.Electrolysis.ElectrolysisBlockEntity;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

public class ElectrolysisBlock extends BaseEntityBlock{
    public ElectrolysisBlock(Properties pProperties) {
        super(pProperties);
    }

    /* ========== Block Entity Boilerplate ========== */

    @Override
    public RenderShape getRenderShape(BlockState pState) {
        // ブロックエンティティを持つブロックは、通常モデルとして描画することを明示します。
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pPos, BlockState pState) {
        // ワールドにこのブロックが置かれた時に、対応するBlockEntityのインスタンスを生成します。
        return new ElectrolysisBlockEntity(pPos, pState);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level pLevel, BlockState pState, BlockEntityType<T> pBlockEntityType) {
        // サーバーサイドでのみtick処理（毎フレームの更新処理）を実行するように設定します。
        if (pLevel.isClientSide()) {
            return null; // クライアントサイドでは何もしない
        }

        // 正しいBlockEntityの型であることを確認し、tickメソッドを呼び出すように設定
        return createTickerHelper(pBlockEntityType, InstantHealModEntities.ELECTROLYSIS_BLOCK_ENTITY.get(), ElectrolysisBlockEntity::tick);
    }

    /* ========== GUI Opening Logic ========== */

    @Override
    public InteractionResult use(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        // サーバーサイド（isClientSide()がfalse）でのみ実行
        if (!pLevel.isClientSide()) {
            BlockEntity entity = pLevel.getBlockEntity(pPos);
            // BlockEntityが正しいインスタンスか確認
            if (entity instanceof ElectrolysisBlockEntity) {
                // NetworkHooksを使って、安全にGUIを開きます。
                // これにより、サーバーとクライアント間で必要なデータが自動的に同期されます。
                NetworkHooks.openScreen((ServerPlayer) pPlayer, (ElectrolysisBlockEntity) entity, pPos);
            } else {
                // もし何らかの理由でBlockEntityが見つからなかった場合
                throw new IllegalStateException("Our Container provider is missing!");
            }
        }

        return InteractionResult.sidedSuccess(pLevel.isClientSide());
    }
}
