package com.Cell_SINON.InstantHealMod.block.ChemicalReactor;

import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.SlotItemHandler;


public class ChemicalReactorMenu extends AbstractContainerMenu{

    public final ChemicalReactorBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    // --- コンストラクタ 1 (クライアントサイド用) ---
    public ChemicalReactorMenu(int pContainerId, Inventory inv, FriendlyByteBuf extraData) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()), new SimpleContainerData(2));
    }

    // --- コンストラクタ 2 (サーバーサイド用 兼 共通処理用) ---
    public ChemicalReactorMenu(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(InstantHealModMenuTypes.CHEMICAL_REACTOR_MENU.get(), pContainerId); // 後で登録
        checkContainerSize(inv, 4);

        if (entity instanceof ChemicalReactorBlockEntity be) {
            this.blockEntity = be;
        } else {
            throw new IllegalStateException("Incorrect BlockEntity type provided for ChemicalReactorMenu!");
        }

        this.level = inv.player.level();
        this.data = data;

        // スロットを追加
        addPlayerInventory(inv);
        addBlockEntitySlots();

        // データを同期
        addDataSlots(data);
    }

    // --- GUIと同期するための計算メソッド ---
    public boolean isCrafting() {
        return this.data.get(0) > 0;
    }
    public int getScaledProgress() {
        int progress = this.data.get(0);
        int maxProgress = this.data.get(1);
        int progressArrowWidth = 24; // GUIテクスチャの矢印の横幅
        return maxProgress != 0 && progress != 0 ? progress * progressArrowWidth / maxProgress : 0;
    }

    // --- 必須のオーバーライドメソッド ---
    @Override
    public boolean stillValid(Player pPlayer) {
        return stillValid(ContainerLevelAccess.create(this.level, this.blockEntity.getBlockPos()),
                pPlayer, InstantHealModBlocks.CHEMICAL_REACTOR_BLOCK.get()); // 後で登録
    }

    @Override
    public ItemStack quickMoveStack(Player pPlayer, int pIndex) {
        // (以前のDistillerMenuからコピー＆ペーストし、スロット数を4に調整)
        return ItemStack.EMPTY; // ← まずは仮実装でOK
    }

    // --- ヘルパーメソッド ---
    private void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }

    private void addBlockEntitySlots() {
        // あなたの図に合わせたスロット配置
        // スロット番号と座標(x, y)を調整
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 0, 26, 35));

        // 中央入力 (スロット1)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 1, 53, 35));

        // 右上出力 (スロット2)
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 2, 107, 35));

        // 右下出力 (スロット3) - 画像にはありませんが、レシピに合わせて追加可能
        // もし出力が1つだけなら、このスロットは不要です。
        this.addSlot(new SlotItemHandler(this.blockEntity.getItemHandler(), 3, 134, 35));
    }
}
