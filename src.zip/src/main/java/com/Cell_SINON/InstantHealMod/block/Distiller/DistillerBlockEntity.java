package com.Cell_SINON.InstantHealMod.block.Distiller;

import com.Cell_SINON.InstantHealMod.Recipe.DistillationRecipe;
import com.Cell_SINON.InstantHealMod.Recipe.ModRecipeTypes;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModEntities;
import com.Cell_SINON.InstantHealMod.block.Distiller.DistillerMenu; // 後で作る
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class DistillerBlockEntity extends BlockEntity implements MenuProvider{
    private final ItemStackHandler itemHandler = new ItemStackHandler(3);
    private static final int FUEL_SLOT = 0, INPUT_SLOT = 1, OUTPUT_SLOT = 2;

    private int progress = 0, maxProgress = 200;
    private int fuelTime = 0, maxFuelTime = 0;
    protected final ContainerData data;

    public DistillerBlockEntity(BlockPos pPos, BlockState pState) {
        super(InstantHealModEntities.DISTILLER_BLOCK_ENTITY.get(), pPos, pState);
        this.data = new ContainerData() {
            public int get(int index) {
                return switch (index) {
                    case 0 -> DistillerBlockEntity.this.progress;
                    case 1 -> DistillerBlockEntity.this.maxProgress;
                    case 2 -> DistillerBlockEntity.this.fuelTime;
                    case 3 -> DistillerBlockEntity.this.maxFuelTime;
                    default -> 0;
                };
            }
            public void set(int index, int value) {
                switch (index) {
                    case 0 -> DistillerBlockEntity.this.progress = value;
                    case 1 -> DistillerBlockEntity.this.maxProgress = value;
                    case 2 -> DistillerBlockEntity.this.fuelTime = value;
                    case 3 -> DistillerBlockEntity.this.maxFuelTime = value;
                }
            }
            public int getCount() { return 4; }
        };
    }

    // ↓↓↓ この行は絶対に不要なので削除！ ↓↓↓
    // private Ingredient recipeItem;

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.instanthealmod.distiller_block");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        return new DistillerMenu(pContainerId, pPlayerInventory, this, this.data);
    }

    public ItemStackHandler getItemHandler() {
        return this.itemHandler;
    }

    @Override
    protected void saveAdditional(CompoundTag pTag) {
        pTag.put("inventory", this.itemHandler.serializeNBT());
        pTag.putInt("distiller.progress", this.progress);
        pTag.putInt("distiller.fuel_time", this.fuelTime);
        pTag.putInt("distiller.max_fuel_time", this.maxFuelTime);
        super.saveAdditional(pTag);
    }
    @Override
    public void load(CompoundTag pTag) {
        super.load(pTag);
        this.itemHandler.deserializeNBT(pTag.getCompound("inventory"));
        this.progress = pTag.getInt("distiller.progress");
        this.fuelTime = pTag.getInt("distiller.fuel_time");
        this.maxFuelTime = pTag.getInt("distiller.max_fuel_time");
    }

    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, DistillerBlockEntity pBlockEntity) {
        if (pLevel.isClientSide()) return;

        boolean isBurning = pBlockEntity.fuelTime > 0;
        if (isBurning) {
            pBlockEntity.fuelTime--;
        }

        Optional<DistillationRecipe> recipe = pLevel.getRecipeManager()
                .getRecipeFor(ModRecipeTypes.DISTILLATION_TYPE.get(), new SimpleContainer(pBlockEntity.itemHandler.getStackInSlot(INPUT_SLOT)), pLevel);

        if (recipe.isPresent() && canInsertItemsIntoOutputSlots(pBlockEntity, recipe.get())) {
            if (!isBurning && !pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT).isEmpty()) {
                pBlockEntity.fuelTime = ForgeHooks.getBurnTime(pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT), RecipeType.SMELTING);
                pBlockEntity.maxFuelTime = pBlockEntity.fuelTime;
                pBlockEntity.itemHandler.getStackInSlot(FUEL_SLOT).shrink(1);
            }
            if (pBlockEntity.fuelTime > 0) {
                pBlockEntity.progress++;
                setChanged(pLevel, pPos, pState);
                if (pBlockEntity.progress >= pBlockEntity.maxProgress) {
                    craftItem(pBlockEntity, recipe.get());
                    pBlockEntity.resetProgress();
                }
            }
        } else {
            pBlockEntity.resetProgress();
            setChanged(pLevel, pPos, pState);
        }
    }

    private void resetProgress() { this.progress = 0; }

    private static void craftItem(DistillerBlockEntity pBlockEntity, DistillationRecipe pRecipe) {
        ItemStack output1 = pRecipe.getOutput1();
        ItemStack output2 = pRecipe.getOutput2();

        pBlockEntity.itemHandler.setStackInSlot(INPUT_SLOT, output2.copy());
        pBlockEntity.itemHandler.setStackInSlot(OUTPUT_SLOT, output1.copy());
    }

    private static boolean canInsertItemsIntoOutputSlots(DistillerBlockEntity pBlockEntity, DistillationRecipe pRecipe) {
        return pBlockEntity.itemHandler.getStackInSlot(OUTPUT_SLOT).is(Items.GLASS_BOTTLE);
    }
}


