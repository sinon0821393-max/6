package com.Cell_SINON.InstantHealMod.block.fermentation;



import com.Cell_SINON.InstantHealMod.regi.InstantHealModBlocks;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModMenuTypes; // 後で作る
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraft.world.level.Level;

public class FermentationMenu extends AbstractContainerMenu{
    public final FermentationBlockEntity blockEntity;
    private final Level level;
    private final ContainerData data;

    // クライアントサイド用コンストラクタ
    public FermentationMenu(int pContainerId, Inventory inv, FriendlyByteBuf extraData) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()), new SimpleContainerData(2));
    }

    // サーバーサイド用コンストラクタ
    public FermentationMenu(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(InstantHealModMenuTypes.FERMENTATION_MENU.get(), pContainerId);
        checkContainerSize(inv, 4); // スロット数を4に
        this.blockEntity = (FermentationBlockEntity) entity;
        this.level = inv.player.level();
        this.data = data;

        // スロットの座標を図に合わせて調整
        // 左側の入力スロット (2つ)
        this.addSlot(new SlotItemHandler(blockEntity.getItemHandler(), 0, 44, 26)); // 上
        this.addSlot(new SlotItemHandler(blockEntity.getItemHandler(), 1, 44, 44)); // 下

        // 右側の出力スロット (2つ)
        this.addSlot(new SlotItemHandler(blockEntity.getItemHandler(), 2, 116, 26)); // 上
        this.addSlot(new SlotItemHandler(blockEntity.getItemHandler(), 3, 116, 44)); // 下

        addPlayerInventory(inv);

        // サーバーからクライアントへ進捗データを同期させる
        addDataSlots(data);
    }

    // 進捗バーの割合を計算するメソッド
    public int getScaledProgress() {
        int progress = this.data.get(0);
        int maxProgress = this.data.get(1);
        int progressArrowSize = 24; // 矢印テクスチャの横幅(ピクセル)

        return maxProgress != 0 && progress != 0 ? progress * progressArrowSize / maxProgress : 0;
    }
    @Override
    public ItemStack quickMoveStack(Player pPlayer, int pIndex) {
        Slot sourceSlot = this.slots.get(pIndex);
        if (sourceSlot == null || !sourceSlot.hasItem()) {
            return ItemStack.EMPTY;
        }

        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack copyOfSourceStack = sourceStack.copy();

        // スロットのインデックス
        // プレイヤーインベントリ: 0-35
        // ブロックエンティティ: 36以降
        // このMODの場合: 入力1(36), 入力2(37), 出力1(38), 出力2(39)

        if (pIndex < 36) {
            // プレイヤーインベントリからブロックのスロットへ
            // (ここでは入力スロットにのみ移動するようにする)
            if (!this.moveItemStackTo(sourceStack, 36, 38, false)) { // 36番から37番まで
                return ItemStack.EMPTY;
            }
        } else if (pIndex < 40) {
            // ブロックのスロットからプレイヤーインベントリへ
            if (!this.moveItemStackTo(sourceStack, 0, 36, false)) { // 0番から35番まで
                return ItemStack.EMPTY;
            }
        } else {
            // 予期せぬインデックス
            return ItemStack.EMPTY;
        }

        if (sourceStack.isEmpty()) {
            sourceSlot.set(ItemStack.EMPTY);
        } else {
            sourceSlot.setChanged();
        }
        sourceSlot.onTake(pPlayer, sourceStack);
        return copyOfSourceStack;
    }
    private void addPlayerInventory(Inventory playerInventory) {
        // プレイヤーのメインインベントリ (3x9スロット)
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }

        // プレイヤーのホットバー (1x9スロット)
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }


}@Override
    public boolean stillValid(Player pPlayer) {
        return stillValid(ContainerLevelAccess.create(this.level, this.blockEntity.getBlockPos()),
                pPlayer, InstantHealModBlocks.FERMENTATIONBLOCK.get());
    }
}




