package com.Cell_SINON.InstantHealMod.item;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.alchemy.Potion;

import java.util.Properties;

public class HeroPotion extends Potion {   public static final Potion HEROPOTION = new Potion(
        );



    }


